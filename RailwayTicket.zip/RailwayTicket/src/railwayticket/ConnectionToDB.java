
package railwayticket;

import java.sql.*;
import javax.swing.JOptionPane;


public class ConnectionToDB {
    Connection con=null;
    
    public Connection EstablishConnection(){
        try {  
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con=DriverManager.getConnection("jdbc:ucanaccess://RailwayTicketingSystem.accdb");
        }
        catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return con;
    }
}
