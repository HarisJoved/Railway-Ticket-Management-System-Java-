
package railwayticket;

import java.sql.*;
import javax.swing.JOptionPane;

public class User extends Member {

    @Override
    public boolean checkLogin(String username,String password){
        String loginSelection="select * from UserTable where Username='"+username+"' and Password='"+password+"'";
        boolean x;
        try {
            pstmt=con_obj.prepareStatement(loginSelection);
            res=pstmt.executeQuery();
            if (res.next()) {
                x=true;
            }
            else{
                x=false;
            }
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
            x=false;
        }
        return x;
    }
    
    @Override
    public boolean registerUser(String username,String password,String cnic){
        boolean x = false;
        String insertingData = "insert into UserTable(Username,Password,CNIC)values('"+username+"','"+password+"','"+cnic+"')";
        try {
         stmt=con_obj.createStatement();
         int result=stmt.executeUpdate(insertingData);
         if(result>0){
             x=true;
         }
         else{
             x=false;
         }
        } 
        catch (SQLException e) {
           JOptionPane.showMessageDialog(null, e);   
        }
        return x;
    }
    
    public boolean fetchData(String uName) {
        boolean b = false;
        String sql = "select * from UserTable where Username='" + uName + "'";

        try {
            pstmt = con_obj.prepareStatement(sql);
            res = pstmt.executeQuery();
            while (res.next()) {

                setUserName(res.getString("Username"));
                setPassWord(res.getString("Password"));
                setCnic(res.getString("CNIC"));
                b = true;
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        return b;
    }
    
    @Override
    public boolean deleteUser(String username){
        boolean x=false;
        String delete="delete from UserTable where Username='"+username+"'";
        try {
            stmt=con_obj.createStatement();
            int result=stmt.executeUpdate(delete);
            if (result>0) {
                x=true;
            }
            else{
                x=false;
            }
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return x;
    }
    
    public boolean updateUser(String uNamee,String username,String pass,String cnic) {
        boolean b;
        String sql = "Update UserTable set Username=? , Password=? , CNIC=? where Username=?";

        try {
            pstmt = con_obj.prepareStatement(sql);
           
            pstmt.setString(1, username);
            pstmt.setString(2, pass);
            pstmt.setString(3, cnic);
            pstmt.setString(4, uNamee);
            pstmt.executeUpdate();
            pstmt.close();
            b=true;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
            b=false;
        }
        return b;
    }
}
