
package railwayticket;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

public class Train {
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj = con.EstablishConnection();
    Statement stmt=null;
    PreparedStatement pstmt=null;
    ResultSet res=null;
    private String ID,name,start,stop,startingTime,endingTime,totalTime;
    

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEndingTime() {
        return endingTime;
    }

    public void setEndingTime(String endingTime) {
        this.endingTime = endingTime;
    }
    
    

    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getStop() {
        return stop;
    }

    public void setStop(String stop) {
        this.stop = stop;
    }

    public String getStartingTime() {
        return startingTime;
    }

    public void setStartingTime(String startingTime) {
        this.startingTime = startingTime;
    }

    public String getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(String totalTime) {
        this.totalTime = totalTime;
    }

    
    
    public void checkTrain(String from,String to,JTable TableSupply){
        String trainSelection="select * from Trains where start='"+from+"' and stop='"+to+"'";

        try {
            pstmt=con_obj.prepareStatement(trainSelection);
            res=pstmt.executeQuery();
            while (res.next()){
                TableSupply.setModel((DbUtils.resultSetToTableModel(res)));
            }
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public boolean fetchData(String start,String stop) {
        boolean b = false;
        String sql = "select * from Table1 where start=? and stop=?";
        try {
            pstmt = con_obj.prepareStatement(sql);
            pstmt.setString(1, start);
            pstmt.setString(2, stop);
            res = pstmt.executeQuery();
            while (res.next()){
                setID(res.getString("ID"));
                setName(res.getString("name"));
                setStartingTime(res.getString("startingTime"));
                setEndingTime(res.getString("endingTime"));
                setTotalTime(res.getString("totalTime"));
                b = true;
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        return b;
    }
}
