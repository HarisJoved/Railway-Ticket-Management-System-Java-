
package railwayticket;

import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Admin extends Member{
 
    
    @Override
    public boolean checkLogin(String username,String password){
        String loginSelection="select * from AdminTable where Username='"+username+"' and Password='"+password+"'";
        boolean x;
        try {
            pstmt=con_obj.prepareStatement(loginSelection);
            res=pstmt.executeQuery();
            if (res.next()) {
                x=true;
            }
            else{
                x=false;
            }
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
            x=false;
        }
        return x;
    }
    @Override
    public boolean registerUser(String username,String password,String cnic){
        boolean x = false;
        String insertingData = "insert into AdminTable(Username,Password,CNIC)values('"+username+"','"+password+"','"+cnic+"')";
        try {
         stmt=con_obj.createStatement();
         int result=stmt.executeUpdate(insertingData);
         if(result>0){
             x=true;
         }
         else{
             x=false;
         }
        } 
        catch (SQLException e) {
           JOptionPane.showMessageDialog(null, e);   
        }
        return x;
    }
    
    public boolean fetchData(String uName) {
        boolean b = false;
        String sql = "select * from AdminTable where Username='" + uName + "'";

        try {
            pstmt = con_obj.prepareStatement(sql);
            res = pstmt.executeQuery();
            while (res.next()) {

                setUserName(res.getString("Username"));
                setPassWord(res.getString("Password"));
                setCnic(res.getString("CNIC"));
                b = true;
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        return b;
    }
    
    @Override
    public boolean deleteUser(String username){
        String delete="delete from AdminTable where Username='"+username+"'";
        boolean x;
        try {
            stmt=con_obj.createStatement();
            int result=stmt.executeUpdate(delete);
            if (result>0){
                x=true;
            }
            else{
                x=false;
            }
        }
        catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
            x=false;
        }
        return x;
    }
}
