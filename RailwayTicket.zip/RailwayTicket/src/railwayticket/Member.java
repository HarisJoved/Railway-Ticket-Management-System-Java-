
package railwayticket;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public abstract class Member {
    ConnectionToDB con=new ConnectionToDB();
    Connection con_obj = con.EstablishConnection();
    Statement stmt=null;
    PreparedStatement pstmt=null;
    ResultSet res=null; 
    private String userName,passWord,cnic;

    public String getCnic() {
        return cnic;
    }
    public void setCnic(String cnic) {
        this.cnic = cnic;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getPassWord() {
        return passWord;
    }
    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }
    
    abstract boolean checkLogin(String username,String password);
    abstract boolean registerUser(String username,String password,String cnic);
    abstract boolean deleteUser(String username);
    abstract boolean fetchData(String uName);
}
